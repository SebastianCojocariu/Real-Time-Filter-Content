package NodeType;
/**
 * NodeFactory class build according to Factory Design Pattern rules.
 */

public class NodeFactory {
/**
 * Returns a Node object
 * @param s tell this method which type of Node to build (AndNode,OrNode,etc).
 * @return A specific Node object according to parameter s.If s is not a valid type of Node,returns null.
 */
    public static Node getNode(String s){
        if(s.equals("&&"))
            return new AndNode();
        if(s.equals("||"))
            return new OrNode();
        if(s.equals("eq"))
            return new EqNode();
        if(s.equals("ne"))
            return new NeNode();
        if(s.equals("ge"))
            return new GeNode();
        if(s.equals("gt"))
            return new GtNode();
        if(s.equals("le"))
            return new LeNode();
        if(s.equals("lt"))
            return new LtNode();

        return null;
    }
}
