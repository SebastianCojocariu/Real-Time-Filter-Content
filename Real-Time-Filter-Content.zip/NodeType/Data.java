package NodeType;

/**
 *Data Class which will store the data of a Node.
 */

public class Data {
    public double value;
    public String name;
}
