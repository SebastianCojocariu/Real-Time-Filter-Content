package NodeType;

/**
 * Visitor interface built to use Visitor Design Pattern.
 */

public interface Visitor {

    public boolean visit(AndNode node);
    public boolean visit(OrNode node);
    public boolean visit(Operand node);
    public boolean visit(EqNode node);
    public boolean visit(NeNode node);
    public boolean visit(GtNode node);
    public boolean visit(GeNode node);
    public boolean visit(LeNode node);
    public boolean visit(LtNode node);

}
