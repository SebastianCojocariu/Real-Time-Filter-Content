package NodeType;
/**
 * Visitable interface built for the use of Visitor Design Pattern
 */

public interface Visitable {
    boolean accept(Visitor visitor);
}
