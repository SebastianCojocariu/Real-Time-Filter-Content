package NodeType;

/**
 *CalculatorVisitor Class which implements Visitor
 *Will be made as a Singleton.
 */

public class CalculatorVisitor implements Visitor{
	private static CalculatorVisitor calculator=null;
	private CalculatorVisitor(){};
	
	public static CalculatorVisitor getCalculatorVisitor(){
		if(calculator == null){
			calculator = new CalculatorVisitor();
		}
		return calculator;
	}
	
	
    public boolean visit(AndNode node){
        return node.left.accept(this)&&node.right.accept(this);
    }

    public boolean visit(OrNode node){
        return node.left.accept(this)||node.right.accept(this);
    }

    public boolean visit(EqNode node){
    	//this means that EqNode will compare its 2 Operands according to their name
        if (node.right.data.name!=null)
            return node.left.data.name.equals(node.right.data.name);
        //this means that EqNode will compare its 2 Operands according to their value
        else
            return node.left.data.value == node.right.data.value;
    }

    public boolean visit(NeNode node){
    	//this means that NeNode will compare its 2 Operands according to their name
        if (node.right.data.name!=null)
            return !node.left.data.name.equals(node.right.data.name);
        //this means that NeNode will compare its 2 Operands according to their value
        else
            return node.left.data.value != node.right.data.value;
    }

    public boolean visit(GeNode node){
        return node.left.data.value>=node.right.data.value;
    }
    
    public boolean visit(GtNode node){
        return node.left.data.value>node.right.data.value;
    }
    
    public boolean visit(LeNode node){
    	return node.left.data.value<=node.right.data.value; }
    
    public boolean visit(LtNode node){
        return node.left.data.value<node.right.data.value;
    }
    
    public boolean visit(Operand node){
        return true;
    }

}
