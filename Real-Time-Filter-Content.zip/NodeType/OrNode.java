package NodeType;

/**
 * Class which extends class Node and implements 
 * Visitable,representing OrNode.
 *  
 */

public class OrNode extends Node implements Visitable {

 // Constructors 
 
    public OrNode(){};
    public OrNode(Node left, Node right){
        super(left,right);
    }
    
/**
 *Method which will be used according to Visitor Design Pattern rules.
 *
 *@param visitor an object of type Visitor
 *@return the result of visit method of this visitor having "this" as parameter.   
 */
    @Override
    public boolean accept(Visitor visitor) {
        return visitor.visit(this);
    }
}
