package NodeType;

/**
 * Class which extends class Node and implements 
 * Visitable,representing an Operand. 
 *  
 */

public class Operand extends Node implements Visitable {


 // Constructors

    public Operand(){ data=new Data(); }
    public Operand(Data data) {
        super(null, null);
        this.data=data;
    }
    public Operand(double value) {
        super(null, null);
        data=new Data();
        data.value=value;
    }
    public Operand(String name) {
        super(null, null);
        data=new Data();
        data.name=name;
    }

/**
 *Method which will be used according to Visitor Design Pattern rules.
 *
 *@param visitor an object of type Visitor
 *@return the result of visit method of this visitor having "this" as parameter.   
 */
    @Override
    public boolean accept(Visitor visitor) {
        return visitor.visit(this);
    }
}
