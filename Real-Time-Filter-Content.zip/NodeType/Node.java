package NodeType;
/**
 * Node Class which implements Visitable.
 */

public class Node implements Visitable {
/**
 * Data consisting of a String name and double value.
 * This field will be used only in an Operand.
 */
    public Data data;  
    public Node left;
    public Node right;
 
  // Constructors
 
    public Node(){};
    public Node(Node left,Node right){
        this.left=left;
        this.right=right;
    }

/**
 * Returns false
 * 
 * @param visitor of type Visitor
 * @return false.
 */
    public boolean accept(Visitor visitor) {
        return false;
    }
}
