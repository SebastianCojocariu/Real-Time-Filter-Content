import java.util.*;
import Observer.*;

public class Main {
    public static void main(String[] args) {
    	
            Scanner in=new Scanner(System.in); 
            //factory de observers;Singleton
            ObserverFactory factory=ObserverFactory.getFactory();
            
            StockGrabber bank=new StockGrabber();
            String line=null;
            //parcurgem linie cu linie
            while( (line = in.nextLine()) != null){
            	//"splitam" linia curenta dupa spatii
                String[] token = line.split("[ ]+");
                
                //daca primul cuvant este "feed"
                if(token[0].equals("feed"))
                   bank.setStock(token[1],Double.parseDouble(token[2]));
                //daca primul cuvant este "print"
                else if(token[0].equals("print")){
                   bank.print(Integer.parseInt(token[1]));
                }
                //daca primul cuvant este "create_obs"
                else if(token[0].equals("create_obs")){
                   String filter=line.substring(token[0].length()+token[1].length()+2);
                   factory.getObserver(bank,filter,Integer.parseInt(token[1]));
                }
                //daca primul cuvant este "delete_obs"
                else if(token[0].equals("delete_obs")){
                   bank.unregister(Integer.parseInt(token[1]));
                }
                //daca primul cuvant este "begin"
                else if(token[0].equals("begin"))
                	continue;
                //daca primul cuvant este "end"
                else if(token[0].equals("end"))
                    break;
                //daca primul cuvant este orice alt cuvant diferite de cele de mai sus iesim
                else
                	break;
            }
           in.close(); 
        
    }
}
