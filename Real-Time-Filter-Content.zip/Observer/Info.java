package Observer;

/**
 * Info Class which contains info about the a specific type of Stock.
 * (valueCurrentStock,ValueLastStock last printed,noChanges until last print,percentage)
 */
public class Info {
    public double valueCurrentStock;
    public double valueLastStock;
    public int noChanges;
    public double percentage;
    

 // Constructors
 
    public Info(){}

    public Info(double valueCurrentStock,int noChanges,double percentage){
        this.valueCurrentStock=valueCurrentStock;
        this.noChanges=noChanges;
        this.percentage=percentage;
    }

}
