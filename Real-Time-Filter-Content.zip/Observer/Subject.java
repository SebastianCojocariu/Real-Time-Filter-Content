package Observer;
/**
 * Subject Class built to use Observer Design Pattern.
 */

public interface Subject {
    void register(Observer o);
    void unregister(int observerID);
    void notifyObservers();
}
