package Observer;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

/**
 * StockGrabber Class which implements Subject.
 */
public class StockGrabber implements Subject {

//treemap of the last valueStock for each type of stock.
    private TreeMap<String,Info> treemap;
//nameStock of the last updated stock
    private String nameStock;
//valueStock of the last updated stock
    private double valueStock;
//list of observers
    private LinkedList<Observer> observers;


 // Constructor    
 
    public StockGrabber(){
        treemap=new TreeMap<String,Info>();
        observers=new LinkedList<Observer>();
    }

    /**
     * Registers an observer in the list of observers.
     * Verify for each stock in the treemap of the Subject if it corresponds to 
     * the observer filter.
     * If corresponds ,that stock will be updated to the treemap of stocks of the observer.
     * 
     * @param o of type Observer
     */
    public void register(Observer o){

        observers.add(o);
        ConcreteObserver observer=(ConcreteObserver)o;
        for(Map.Entry<String,Info> entry:treemap.entrySet()){
            String nameStock=entry.getKey();
            Info info=entry.getValue();
            observer.arbore.fillData(nameStock,info.valueCurrentStock);
            if(observer.arbore.check())
                observer.treemap.put(nameStock,new Info(info.valueCurrentStock,0,0));
        
        }
    }
    /**
     * Delete an observer from the observers list,according to its ID
     * 
     * @param observerID of type int
     */
    public void unregister(int observerID){
    	Iterator<Observer> it=observers.iterator();
        while(it.hasNext())
            if(((ConcreteObserver)it.next()).observerID == observerID)
                it.remove();
    }
    
    /**
     * Notify all observers from observers list
     */
    public void notifyObservers(){
        for(Observer o:observers){
            o.update(nameStock,valueStock);
        }
    }
    
    /**
     * Notify all observers when a stock is updated
     * @param nameStock the name of the stock updated
     * @param valueStock the value of the stock updated
     * 
     */
    public void setStock(String nameStock,double valueStock){
        this.nameStock=nameStock;
        this.valueStock=valueStock;
            if(treemap.get(nameStock)!=null) {
                Info info = treemap.get(nameStock);
                info.valueCurrentStock = valueStock;
                treemap.put(nameStock,info);
            }
            else
                treemap.put(nameStock,new Info(valueStock,0,0));
            
        notifyObservers();
    }

    /**
     * Print each stock of the observer which have the ID given as parameter as follows:
     * for each stock which accepts the filter of the observer,will be printed the name 
     * of the stock,the value of it(the last one),the percentage of the difference between 
     * the values of the 2 prints and the number of changes until last print.
     * @param observerID of type int
     */
    public void print(int observerID){
    	//cautam in lista de observers acel observer cu observerID primit ca parametru
        for(Observer o:observers)
        	//daca am gasit observerul cu acel ID
            if(((ConcreteObserver)o).observerID == observerID)
            {
                ConcreteObserver concreteObserver=(ConcreteObserver)o;
                //parcurgem fiecare stock din treemapul acestui observer
                for(Map.Entry<String,Info> entry:concreteObserver.treemap.entrySet()){
                    String nameStock=entry.getKey();
                    Info info=entry.getValue();
                    //actualizam campul data pentru a putea verifica daca respecta filtrul
                    concreteObserver.arbore.fillData(nameStock,info.valueCurrentStock);
                    //daca respecta filtrul
                    if(concreteObserver.arbore.check()){
                    	//daca valueLastStock este 0 inseamna ca nu a mai fost dat niciun print pana atunci
                    	//deci percentage=0.
                        if(info.valueLastStock==0)
                            info.percentage=0;
                        else
                            info.percentage=(info.valueCurrentStock/info.valueLastStock-1)*100;

                        System.out.printf("obs %d: %s %.2f %.2f%% %d\n",concreteObserver.observerID,nameStock,
                                info.valueCurrentStock,info.percentage, info.noChanges);
                        
                        info.valueLastStock=info.valueCurrentStock;
                        info.noChanges=0;
                        concreteObserver.treemap.put(nameStock,info);
                    }
                   
                }
            }
    }
}
