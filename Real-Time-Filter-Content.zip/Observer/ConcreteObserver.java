package Observer;
import java.util.TreeMap;

import Observer.CreateArbore;
import Observer.Info;
import Observer.Observer;
import Observer.Subject;
/**
 * ConcreteObserver Class which implements Observer
 */
public class ConcreteObserver implements Observer{

//treemap cu stocurile primite de la Subject(actualizate la fiecare feed)
    public TreeMap<String,Info> treemap;
    public int observerID;
    
//filtrul transformat in arbore
    public CreateArbore arbore;
    
    public Subject stockGrabber;

//Constructors
    public ConcreteObserver(){}

    public ConcreteObserver(Subject stockGrabber,String filter,int observerID){
        treemap=new TreeMap<String,Info>();
        this.observerID=observerID;
        this.stockGrabber=stockGrabber;
        arbore=new CreateArbore();
        arbore.getArbore(filter);
        stockGrabber.register(this);
        
    }
    
    public void update(String nameStock,double valueCurrentStock){
        //daca stockul primit nu exista in treemap,il introducem in treemap
    	if(!treemap.containsKey(nameStock)){
    	    arbore.fillData(nameStock, valueCurrentStock);
    	    treemap.put(nameStock,new Info(valueCurrentStock,1,0.00));
    	}
    	//daca stockul primit exista,actualizam noChanges si valueCurrentStock aferente Stockului primit.
        else{
            Info info=treemap.get(nameStock);
            info.valueCurrentStock=valueCurrentStock;
            info.noChanges++;
            treemap.put(nameStock,info);
        }
    }
}
