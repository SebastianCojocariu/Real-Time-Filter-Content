package Observer;

import NodeType.*;

import java.util.Stack;
/**
 * CreateArbore Class have a method to convert an expression from postfix into a binary tree,
 * and a method to check if the Data specified in the data field and the tree generated 
 * will return true or false.
 */

public class CreateArbore{
    //nodul de inceput al binary tree-ului.
	public Node start;
    public Data data=new Data();

 //Constructors
 
    public CreateArbore(){ }
    public CreateArbore(Data data){
        this.data=data;
    }
    public CreateArbore(double value){
        this.data.value=value;
    }

    public CreateArbore(String name){
        this.data.name=name;
    }
    public CreateArbore(double value,String name){
        this.data.value=value;
        this.data.name=name;
    }

    //actualizeaza campurile stockName si value din campul data
    public void fillData(String stockName,double value){
        data.value=value;
        data.name=stockName;
    }

/**
 * Actualizeaza campul start cu inceputul tree-ului binar format.
 * @param s String representing postfix conversion of a boolean expression
 */
    public void getArbore(String s){
    	//daca s=="nil" atunci start=new Operand(a carui accept va fi mereu true,dupa cum l-am definit ulterior 
    	//in CalculatorVisitor.
        if(s.equals("nil")){
            start=new Operand();
            return;
        }
        //altfel
        String convert = PrefixToPostfix.getPostfix(s);
        //initializam stack:stiva de noduri
        Stack<Node> stack=new Stack<Node>();
        String[] token=convert.split("[ ]+");

        for(int i=0;i<token.length;i++){
        	//daca avem un camp cu name/value inseamna ca el va fi ulterior completat,
        	//deci creem un Operand si dam adresa lui data ca parametru.
            if(token[i].equals("name")||token[i].equals("value")){
                Operand node=new Operand(data);
                stack.push(node);
            }
            //daca avem un operator,generam cu NodeFactory un nod de tipul operatorului curent,si din moment ce
            //stringul nostru este in postfix,stim sigur ca inainte am avut macar 2 operanzi,deci scoatem de 2 ori
            //de pe stiva si actualizam nodul anterior creat.Facem push de nodul acesta pe stiva.
            else if(PrefixToPostfix.priority(token[i])!=0){
                Node node= NodeFactory.getNode(token[i]);
                node.right=stack.pop();
                node.left=stack.pop();
                stack.push(node);

            }
            //inseamna ca am dat de un name sau o valoare(ex:"GOLD","4.8",etc).
            //Cream un operand de tipul primit si il introducem in stiva. 
            else{
                Operand node;
                if(token[i].charAt(0)>='0'&&token[i].charAt(0)<='9')
                    node=new Operand(Double.parseDouble(token[i]));
                else
                    node=new Operand(token[i]);

                stack.push(node);
            }
        }
        //actualizam start
        if(!stack.isEmpty())
        start=stack.pop();
    }
/**
 * 
 * @return the result of data field applied to the binary tree held in start field.
 */
    public boolean check(){
             return start.accept(CalculatorVisitor.getCalculatorVisitor());
    }
}
