package Observer;
/**
 * ObserverFactory Class will be implemented as Singleton Pattern
 */
public class ObserverFactory {
	private static ObserverFactory observerFactory=null;
	
	private ObserverFactory(){};
	
	public static ObserverFactory getFactory(){
		if(observerFactory == null){
			observerFactory = new ObserverFactory();
		}
		return observerFactory;
	}
	
	/**
	 * 
	 * @param stockGrabber of type Subject
	 * @param filter  String representing a boolean expression
	 * @param observerID of type int
	 * @return and object of type Observer which will have the stockGrabber,filter and observerID
	 * given as parameters.
	 */
	public static Observer getObserver(Subject stockGrabber,String filter,int observerID){
		ConcreteObserver concreteObserver=new ConcreteObserver(stockGrabber,filter,observerID);
		return concreteObserver;
	}
	
}
