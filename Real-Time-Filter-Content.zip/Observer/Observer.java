package Observer;
/**
 * Observer interface built to use Observer Design Pattern.
 */
public interface Observer {
    public void update(String nameStock,double valueStock);
}
