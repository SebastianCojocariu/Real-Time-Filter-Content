package Observer;
import java.util.Stack;
/**
 * PrefixToPostfix Class which have the method of converting a string representing
 * a boolean expression in prefix/infix form into a string in postfix form.
 */
public class PrefixToPostfix {
	/**
	 * Returns the priority of an operator
	 * @param s A string representing a type of operator
	 * @return the priority of the s.
	 */
    static int priority(String s) {
    	
    	if (s.equals("eq") || s.equals("ne") || s.equals("gt")
    			|| s.equals("ge") || s.equals("lt") || s.equals("le"))
            return 3;
    	
        if (s.equals("&&"))
            return 2;
        
        if (s.equals("||"))
            return 1;
        
        return 0;
    }
/**
 * Returns the conversion of the string given as parameter into postfix form
 * @param s a boolean expression in prefix/infix
 * @return the conversion in postfix,as a string.
 */
    static String getPostfix(String s) {
        String res = "";
        int i = 0;
        Stack<String> stack = new Stack<String>();
        //inlocuim fiecare paranteza '(' si ')' cu ' ( ',respectiv ' ) ' pentru a putea parsa stringul cu split usor.
        s = s.replaceAll("[)]", " ) ");
        s = s.replaceAll("[(]", " ( ");
        //sarim peste primul spatiu.
        s=s.substring(1);
        String[] token = s.split("\\s+");

        for (i=0; i < token.length; i++) {
        	//daca e '(' introducem in stiva
            if (token[i].equals("(")) {
                stack.add(token[i]);
            } 
            //daca e ')' scoatem tot ce e in stiva pana intalnim '(' si punem in stringul aferent rezultatului.
            else if (token[i].equals(")")) {
                while (!stack.isEmpty() && !stack.peek().equals("(")) {
                    res = res + stack.pop() + " ";
                }
                stack.pop();
            } 
            //daca avem cu siguranta un operator,golim stiva si copiem in res atata timp cat prioritatea elementului din vf stivei
            //e mai mare sau egala cu prioritatea operatorului curent.
            else if (priority(token[i]) != 0) {
                while (!stack.isEmpty() && priority(stack.peek()) >= priority(token[i])) {
                    res = res + stack.peek() + " ";
                    stack.pop();
                }
                stack.add(token[i]);
            } 
            //altfel avem un operand,deci il copiem in res.
            else 
                res = res + token[i] + " ";
        }
        
        //punem in res ce a mai ramas in stiva
        while (!stack.isEmpty())
            res = res + stack.pop() + " ";
        //returnam res
        return res;

    }
}
